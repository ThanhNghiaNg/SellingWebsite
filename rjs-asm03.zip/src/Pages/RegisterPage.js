const RegisterPage = (props) => {
  return <div>RegisterPage</div>;
};

export default RegisterPage;
