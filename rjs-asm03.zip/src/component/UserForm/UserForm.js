import classes from "./UserForm.module.css";
import Button from "../UI/Button";
import React, { useRef, useState } from "react";
import { userActions } from "../../store/users";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

const UserForm = (props) => {
  const userArr = useSelector((state) => state.users.userArr);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [isLogining, setIsLogining] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [password, setPassword] = useState("");
  const fullNameRef = useRef();
  const emailRef = useRef();
  const phoneRef = useRef();
  const changeFormHandler = () => {
    setIsLogining((prevState) => !prevState);
    setSuccess("");
    setError("");
  };
  const changePasswordHandler = (event) => {
    setPassword(event.target.value);
  };
  const submitHandler = (event) => {
    event.preventDefault();
    if (!emailRef.current.value) {
      setError("Email must not me empty.");
      return;
    } else if (!password) {
      setError("Password must not me empty.");
      return;
    }
    if (isLogining) {
      const idxUser = userArr.findIndex(
        (user) => user.email === emailRef.current.value
      );
      if (idxUser !== -1 && password === userArr[idxUser].password) {
        dispatch(
          userActions.login({
            name: userArr[idxUser].name,
            email: emailRef.current.value,
            password: password,
            phone: userArr[idxUser].phone,
          })
        );
        setSuccess("Register Successfuly!");
        setError("");
        setTimeout(() => {
          navigate("/");
        }, 1000);
      } else {
        setPassword("");
        setError("Wrong email or password!");
      }
    } else {
      if (!fullNameRef.current.value) {
        setError("Please enter your full name.");
      } else if (!emailRef.current.value.includes("@")) {
        setError("Please enter a valid email.");
      } else if (password.length <= 8) {
        setError("Password must have more than 8 characters.");
      } else if (!phoneRef.current.value) {
        setError("Please enter your phone number.");
      } else if (!Number.isInteger(Number(phoneRef.current.value))) {
        setError("Please enter a valid phone number.");
      } else if (
        userArr.findIndex((user) => user.email === emailRef.current.value) !==
        -1
      ) {
        setError("Email already exist.");
      } else {
        dispatch(
          userActions.addUser({
            name: fullNameRef.current.value,
            email: emailRef.current.value,
            password: password,
            phone: phoneRef.current.value,
          })
        );
        setSuccess("Register Successfuly!");
        setTimeout(() => {
          changeFormHandler();
        }, 1000);
      }
    }
  };
  console.log(userArr);
  return (
    <form className={classes.form}>
      <p className="fs-3 fst-italic text-center pb-2">
        Sign {!isLogining ? "Up" : "In"}
      </p>
      <div className={classes["input-controls"]}>
        {!isLogining && (
          <input type="text" placeholder="Full name" ref={fullNameRef}></input>
        )}
        <input type="email" placeholder="Email" ref={emailRef}></input>
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={changePasswordHandler}
        ></input>

        {!isLogining && (
          <input type="text" placeholder="Phone" ref={phoneRef}></input>
        )}
      </div>
      {error && <p className="text-danger">{error}</p>}
      {success && <p className="text-success">{success}</p>}
      <Button onClick={submitHandler}>SIGN {!isLogining ? "UP" : "IN"}</Button>
      <div className={classes.switch}>
        <span>{!isLogining ? "Login" : "Create an account"}</span>?{" "}
        <span onClick={changeFormHandler}>
          {!isLogining ? "Click" : "Sign up"}
        </span>
      </div>
    </form>
  );
};

export default UserForm;
